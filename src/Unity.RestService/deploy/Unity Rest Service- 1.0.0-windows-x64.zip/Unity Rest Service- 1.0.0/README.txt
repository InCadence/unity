----------------
--Installation--
----------------

1. Make sure winzip is installed
2. Run install.bat as Admin

-------------
--Uninstall--
-------------

1. Run uninstall.bat as Admin

------------------------
--Update Unity Service--
------------------------

1. place updated WAR file in bin directory (overwrite existing)
2. Run update.bat as Admin

--------------------------------------------
--Change Default port for UnityRestService--
--------------------------------------------

1. Open server.xml in conf directory
2. Change port attribute of Connector node to new port number